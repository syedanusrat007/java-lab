
package class3;


public class String {
    String name;
    java.lang.String s = new java.lang.String();
}
