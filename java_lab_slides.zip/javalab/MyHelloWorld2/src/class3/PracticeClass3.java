
package class3;



public class PracticeClass3 {
    public int i;
    private double d;
    protected char c;
    boolean b;
    //public final int FIXED_VALUE =100;
    
    public static void main(String[] args) {
//        B b = new B(10);
//        System.out.println(b.sum()); 
    }
    
    
//    public char getC() {
//        return c;
//    }
//
//    public void setC(char c) {
//        this.c = c;
//    }
//
//    public int getI() {
//        return i;
//    }
//
//    public void setI(int i) {
//        this.i = i;
//    }
//
//    public double getD() {
//        return d;
//    }
//
//    public void setD(double d) {
//        this.d = d;
//    }
//
//    public boolean isB() {
//        return b;
//    }
//
//    public void setB(boolean b) {
//        this.b = b;
//    }

   
//    public PracticeClass3(int i) {
//        this.i = i;
//    }
//
//    public PracticeClass3(int i, double d, char c, boolean b) {
//        this.i = i;
//        this.d = d;
//        this.c = c;
//        this.b = b;
//    }
//
//    public PracticeClass3(int i, double d) {
//        this.i = i;
//        this.d = d;
//    }
//    
    
}


//class A{
//    private int i;
//    protected char c;
//
//    public A(int i) {
//        this.i = i;
//    }
//
//    public A(int i, char c) {
//        this.i = i;
//        this.c = c;
//    }
//
//    public  int sum(){
//        return i+100;
//    }
//    
//    
//}
//
//class B extends A{
//    
//    private double d;
//    protected int c;
//    public B(int c) {
//        super(10,'A');
//        this.c = c;
//        super.c = (char)c;
//    }
//    @Override
//    public int sum(){
//        return c+100;
//    }
//    
//}


